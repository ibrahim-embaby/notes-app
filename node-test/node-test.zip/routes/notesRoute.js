const router = require("express").Router();
const jwt = require("jsonwebtoken");
const { Note } = require("../models/Note");
const { createNoteCtrl } = require("../controllers/noteControllers");

router.post("/", createNoteCtrl);

router.get("/", async (req, res) => {
  const token = req.headers.authorization.split(" ")[1];
  if (!token) {
    return res.status(400).json({ message: "no token" });
  }
  const userVerified = jwt.verify(token, process.env.SECRET_KEY);

  if (!userVerified) {
    return res.status(400).json({ message: "user not authenticated" });
  }

  const notes = await Note.find({ userId: userVerified.id }).populate("userId");
  res.status(200).json({ notes });
});

router.get("/:id", async (req, res) => {
  const data = req.headers.authorization.split(" ")[1];
  const user = jwt.verify(data, process.env.SECRET_KEY);
  if (!user) {
    return res.status(401).json({ message: "user not authenticated" });
  }

  const note = await Note.findOne({ userId: user.id, _id: req.params.id });

  res.status(200).json({ note });
});

router.put("/:id", async (req, res) => {
  const data = req.headers.authorization.split(" ")[1];
  const user = jwt.verify(data, process.env.SECRET_KEY);

  if (!user) {
    return res.status(401).json({ message: "error" });
  }
  const note = await Note.findById(req.params.id);

  if (note.userId.toString() !== user.id) {
    return res.status(403).json({ message: "not authorized" });
  }

  const updatedNote = await Note.findByIdAndUpdate(
    note._id,
    {
      title: req.body.title,
      content: req.body.content,
    },
    { new: true }
  );

  res.status(200).json({ success: true, message: "success", updatedNote });
});

router.delete("/:id", async (req, res) => {
  const data = req.headers.authorization.split(" ")[1];
  const user = jwt.verify(data, process.env.SECRET_KEY);
  if (!user) {
    return res.status(401).json({ message: "error" });
  }
  const deletedNote = await Note.findOneAndDelete({
    userId: user.id,
    _id: req.params.id,
  });

  res.status(200).json({ success: true, message: "success", deletedNote });
});

module.exports = router;
