const jwt = require("jsonwebtoken");
const { Note } = require("../models/Note");

/**
 * @description create note function
 * @route /notes
 * @method post
 * @access private(logged user)
 */
module.exports.createNoteCtrl = async (req, res) => {
  try {
    const data = req.headers.authorization.split(" ")[1];
    const userVerified = jwt.verify(data, process.env.SECRET_KEY);

    if (!userVerified) {
      return res.status(400).json({ message: "user not authenticated" });
    }

    const note = await Note.create({
      userId: userVerified.id,
      title: req.body.title,
      content: req.body.content,
    });

    res.status(200).json({ note: note, message: "success" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error });
  }
};
