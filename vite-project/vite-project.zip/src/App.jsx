import { useEffect, useState } from "react";
import "./App.css";
import SignUp from "./pages/SignUp";
import { Navigate, Route, Routes, useNavigate } from "react-router-dom";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import AddNote from "./pages/AddNote";
import Note from "./pages/Note";
import UpdateNote from "./pages/UpdateNote";

function App() {
  const [user, setUser] = useState(JSON.parse(localStorage.getItem("user")));
  const navigate = useNavigate();

  useEffect(() => {
    console.log("first");
    if (!user) {
      // navigate("/login");
    } else {
      navigate("/dashboard");
    }
  }, [user]);

  console.log(user);
  return (
    <>
      <Routes>
        <Route
          path="/signup"
          element={user ? <Navigate to={"/dashboard"} /> : <SignUp />}
        />
        <Route
          path="/login"
          element={
            user ? <Navigate to={"/dashboard"} /> : <Login setUser={setUser} />
          }
        />
        <Route
          path="/"
          element={
            user ? <Navigate to={"/dashboard"} /> : <Navigate to={"/login"} />
          }
        />
        <Route
          path="/dashboard"
          element={
            user ? (
              <Dashboard user={user} setUser={setUser} />
            ) : (
              <Navigate to={"/login"} />
            )
          }
        />
        <Route
          path="/add-note"
          element={user ? <AddNote user={user} /> : <Navigate to={"/login"} />}
        />

        <Route path="/notes/:id" element={<Note user={user} />} />
        <Route path="/notes/:id/edit" element={<UpdateNote user={user} />} />
      </Routes>
    </>
  );
}

export default App;
