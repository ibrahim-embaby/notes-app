import React from "react";

function NoteForm() {
  return (
    <div>
      <label htmlFor="">title</label>
      <input type="text" />

      <label htmlFor="">content</label>
      <textarea name="" id=""></textarea>
    </div>
  );
}

export default NoteForm;
